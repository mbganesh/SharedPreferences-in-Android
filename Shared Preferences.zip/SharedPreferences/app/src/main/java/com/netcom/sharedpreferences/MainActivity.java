package com.netcom.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    EditText editText ;
    Button button , view;
    String temp, text;
    ImageView ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.getNumberFieldId);
        button = findViewById(R.id.submitBtn);
        view = findViewById(R.id.viewId);
        ref = findViewById(R.id.refreshId);
        ref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setText("");
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext() , DisplayActivity.class);
                startActivity(i);
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String check = editText.getText().toString();
                if (TextUtils.isEmpty(check)){

                    Snackbar snackBar = Snackbar .make(v, "Please Enter Mobile Number!", Snackbar.LENGTH_LONG).setAction("Example", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            editText.setHint("9507171041");
                        }
                    });

                    snackBar.setActionTextColor(Color.RED);
                    snackBar.show();
                }else {
                    saveData();
                }
            }
        });

        loadData();
    }

    public void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPref" , MODE_PRIVATE);
        String display = sharedPreferences.getString("NUMBER" , "");
        editText.setText(display);
    }


    private void saveData() {
        temp = editText.getText().toString();

        Intent i = new Intent(getApplicationContext() , DisplayActivity.class);
        i.putExtra("num" , temp);

        SharedPreferences sharedPreferences = getSharedPreferences("sharedPref" , MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("NUMBER" , temp);
        editor.apply();

        startActivity(i);
    }



}